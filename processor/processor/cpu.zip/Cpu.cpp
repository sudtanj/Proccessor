#include "Cpu.h"

Cpu::Cpu(int bit,int regist) {
	std::vector<bool> temp;
	for (int j = 0;j < regist;j++) {
		temp.clear();
		for (int i = 0;i < bit;i++) {
			temp.push_back(new bool());
		}
		this->rgstr.push_back(temp);
	}
}

void Cpu::checkRegister() {
	for (std::vector<bool> temp : this->rgstr) {
		for (bool temporary : temp) {
			std::cout << temporary<<" ";
		}
		std::cout << std::endl;
	}
}

void Cpu::setBinary(bool binary, int regist, int location) {
	this->rgstr.at(regist).at(location) = binary;
}