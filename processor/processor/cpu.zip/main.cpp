#include <iostream>
#include "Cpu.h"
using namespace std;

int main() {
	Cpu* prosesor = new Cpu(16,5);
	prosesor->checkRegister();
	prosesor->setBinary(false,0,1);
	prosesor->checkRegister();
	system("pause");
	return 0;
}