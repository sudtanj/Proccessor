#pragma once
#include <vector>
#include <iostream>


class Cpu {
	private:
		 std::vector<std::vector<bool>> rgstr;
	public:
		Cpu(int bit, int regist);
		void checkRegister();
		void setBinary(bool binary, int regist, int location);
};